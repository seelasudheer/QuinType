import React from 'react';
import './App.css';
import Mailbu from './POC/Mailbu';
import './POC/styles.css'

function App() {
  return (
    <div style={{backgroundColor:"rgba(232, 232, 232, 0.10)"}}>
    <div className="container">
       <Mailbu/>
    </div>
    </div>
  );
}

export default App;
